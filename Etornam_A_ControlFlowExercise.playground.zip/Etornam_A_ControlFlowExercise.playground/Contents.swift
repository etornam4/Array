import UIKit
var crocsCollection: [String] = ["Digital Aqua"]

crocsCollection += ["Lemon"]

print ("My first array has \(crocsCollection.count) items.")

var crocsIWant: [String] = ["Lavender", "Fresco", "Lime Zest"]

crocsIWant += ["Mineral Blue", "Pink Lemonade", "Black", "Slate Gray", "White"]
print ("My second array has \(crocsIWant.count) items.")
print ( "I love Crocs 😁")
